"""WebSocket Authentication Middleware."""
import jwt
import os
from typing import Optional, Dict, Any
from fastapi import WebSocket, WebSocketDisconnect, status
from dataclasses import dataclass, field

@dataclass
class WebSocketAuthConfig:
    """WebSocket authentication configuration."""
    secret_key: str = None
    algorithm: str = "HS256"
    require_auth: bool = True
    
    def __post_init__(self):
        if self.secret_key is None:
            self.secret_key = os.getenv("JWT_SECRET", "")
            # If require_auth is True, we might want to warn or error, but let's be permissive if not set for dev
            if not self.secret_key and self.require_auth:
                 # In a real app, this should probably raise, but for now let's allow it 
                 # or maybe we should just default to a dev secret?
                 # Let's keep the user provided logic:
                 pass

class WebSocketAuthenticator:
    """Authenticate WebSocket connections."""
    
    def __init__(self, config: Optional[WebSocketAuthConfig] = None):
        self.config = config or WebSocketAuthConfig(require_auth=False)
        if self.config.require_auth and not self.config.secret_key:
             # Try to get from env again just in case
             self.config.secret_key = os.getenv("JWT_SECRET", "")
             if not self.config.secret_key:
                 raise ValueError("JWT_SECRET required for WebSocket auth")
        
    async def authenticate(self, websocket: WebSocket) -> Optional[Dict[str, Any]]:
        """Authenticate a WebSocket connection.
        
        Returns:
            Dict with user info if authenticated, None if connection closed.
        """
        if not self.config.require_auth:
            return {"user": "anonymous", "authenticated": False}
            
        # Get token from query params or headers
        token = websocket.query_params.get("token")
        
        # Also check headers (though standard JS WebSocket API doesn't support custom headers easily,
        # some clients do, or it might be passed in Sec-WebSocket-Protocol)
        if not token:
            auth_header = websocket.headers.get("authorization", "")
            if auth_header.startswith("Bearer "):
                token = auth_header[7:]
        
        # Check Sec-WebSocket-Protocol as a fallback mechanism for browsers
        if not token:
            protocols = websocket.headers.get("sec-websocket-protocol", "")
            if protocols:
                # It might be a list "soap, json, <token>"
                for part in protocols.split(','):
                    part = part.strip()
                    # simplistic check: if it looks like a JWT (3 parts separated by dots)
                    if len(part.split('.')) == 3:
                        token = part
                        break
                
        if not token:
            # We must close the connection if auth is required and missing
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="Authentication required")
            return None
            
        try:
            payload = jwt.decode(
                token,
                self.config.secret_key,
                algorithms=[self.config.algorithm]
            )
            return {"user": payload.get("sub"), "authenticated": True, "payload": payload}
        except jwt.ExpiredSignatureError:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason="Token expired")
            return None
        except jwt.InvalidTokenError as e:
            await websocket.close(code=status.WS_1008_POLICY_VIOLATION, reason=f"Invalid token: {str(e)}")
            return None
