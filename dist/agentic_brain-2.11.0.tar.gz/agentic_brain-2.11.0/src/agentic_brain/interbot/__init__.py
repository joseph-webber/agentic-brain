"""Inter-Bot Communication - LLMs talking to each other."""

from .protocol import (
    CHANNELS,
    FINAL_PROTOCOL,
    PROTOCOL,
    BotMessage,
    InterBotProtocol,
    MessageType,
    Priority,
)
from .coordinator import BotCoordinator

__all__ = [
    "BotMessage",
    "MessageType",
    "Priority",
    "CHANNELS",
    "PROTOCOL",
    "FINAL_PROTOCOL",
    "InterBotProtocol",
    "BotCoordinator",
]
