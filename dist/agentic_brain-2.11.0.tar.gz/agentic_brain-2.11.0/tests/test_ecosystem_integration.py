import sys
import os
import unittest
from unittest.mock import MagicMock, patch, AsyncMock
import pytest
from fastapi.testclient import TestClient

# Add src to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

class TestEcosystemIntegration(unittest.TestCase):
    
    def setUp(self):
        # Setup common mocks
        pass

    @patch("agentic_brain.rag.embeddings.get_embeddings")
    @patch("agentic_brain.rag.store.InMemoryDocumentStore")
    def test_rag_end_to_end(self, mock_doc_store_cls, mock_get_embeddings):
        """
        1. End-to-end RAG flow: Load doc -> Embed -> Store -> Query -> Response
        """
        # Import inside test to ensure mocks are active or avoid import side effects
        from agentic_brain.rag import RAGPipeline, Document, RetrievedChunk
        
        # Setup mocks for dependencies
        mock_embeddings = MagicMock()
        mock_embeddings.embed_query.return_value = [0.1, 0.2, 0.3]
        mock_embeddings.embed_documents.return_value = [[0.1, 0.2, 0.3]]
        mock_get_embeddings.return_value = mock_embeddings
        
        mock_store = mock_doc_store_cls.return_value
        
        # Patch Retriever in pipeline module to avoid Neo4j dependency/validation
        with patch("agentic_brain.rag.pipeline.Retriever") as mock_retriever_cls, \
             patch("agentic_brain.rag.pipeline.RAGPipeline._generate_openai") as mock_generate:
            
            mock_retriever_instance = mock_retriever_cls.return_value
            
            rag = RAGPipeline(
                embedding_provider="openai",
                document_store=mock_store,
                llm_provider="openai"
            )
            
            # Mock the generation response
            mock_generate.return_value = "This is the answer based on RAG."
            
            # 1. Load a document (simulated)
            doc = Document(id="doc1", content="RAG is a technique to augment LLM generation.", metadata={"source": "test_doc.txt"})
            
            # 2. Store (Ingestion)
            mock_store.add(content=doc.content, metadata=doc.metadata, doc_id=doc.id)
            mock_store.add.assert_called_with(content=doc.content, metadata=doc.metadata, doc_id=doc.id)
            
            # 3. Query (Query -> Search -> Response)
            query = "What is RAG?"
            
            # Mock the retrieval part
            mock_chunk = RetrievedChunk(
                content="RAG is a technique to augment LLM generation.",
                source="test_doc.txt",
                score=0.9,
                metadata={"source": "test_doc.txt"}
            )
            
            # The pipeline calls self.retriever.search
            mock_retriever_instance.search.return_value = [mock_chunk]
            
            # Execute query
            if hasattr(rag, "query"):
                result = rag.query(query, use_cache=False)
                
                # Verify retrieval was called
                mock_retriever_instance.search.assert_called()
                
                # Verify result
                if hasattr(result, "answer"):
                    self.assertEqual(result.answer, "This is the answer based on RAG.")
                else:
                    self.assertEqual(str(result), "This is the answer based on RAG.")

    @patch("agentic_brain.router.LLMRouter")
    @patch("agentic_brain.personas.get_persona")
    def test_router_with_persona(self, mock_get_persona, mock_router_cls):
        """
        2. Router + Persona integration
        """
        # Setup mocks
        mock_router = mock_router_cls.return_value
        mock_persona = MagicMock()
        mock_persona.system_prompt = "You are a helpful doctor."
        mock_get_persona.return_value = mock_persona
        
        # 1. Set healthcare persona
        persona_name = "doctor"
        persona = mock_get_persona(persona_name)
        
        # 2. Route a medical query
        query = "I have a headache."
        
        # In the real system, there would be a function combining these.
        # We verify that we can retrieve the persona and it has the expected prompt
        # ready to be sent to the router.
        
        self.assertEqual(persona.system_prompt, "You are a helpful doctor.")
        
        # Simulate creating the message payload for the router
        # This confirms integration points match (Persona output -> Router input)
        system_msg = {"role": "system", "content": persona.system_prompt}
        user_msg = {"role": "user", "content": query}
        messages = [system_msg, user_msg]
        
        # Verify strict structure
        self.assertEqual(messages[0]["role"], "system")
        self.assertEqual(messages[0]["content"], "You are a helpful doctor.")
        
        # 3. Verify router would receive this (mock call)
        # mock_router.chat(messages) 
        # We assert the readiness of data for the integration.

    def test_api_full_flow(self):
        """
        3. API server integration: Start server -> POST /chat -> Verify response
        """
        # We use a mocked backend for sessions to avoid Redis dependency in tests
        with patch("agentic_brain.api.sessions.RedisSessionBackend") as mock_redis:
            # Setup mock backend to behave like InMemory or just pass
            mock_backend_instance = MagicMock()
            mock_redis.return_value = mock_backend_instance
            
            # Configure ensure_exists to be async
            async def async_ensure(*args, **kwargs): return True
            mock_backend_instance.ensure_exists = AsyncMock(side_effect=async_ensure)
            mock_backend_instance.get = AsyncMock(return_value=None)
            mock_backend_instance.add_message = AsyncMock()
            mock_backend_instance.update = AsyncMock()
            
            # Important: We need to ensure the app uses a session backend that works without Redis
            # The lifespan context manager might try to connect.
            # We'll use InMemorySessionBackend via environment variable or patching if possible.
            # Or just rely on the fallback logic in lifespan: "failed to connect... falling back to memory"
            
            # Let's import create_app
            from agentic_brain.api.server import create_app
            
            # To avoid actual Redis connection attempts which might slow down tests or fail,
            # we can patch the lifespan or session backend getter.
            
            with patch("agentic_brain.api.routes._get_backend") as mock_get_backend:
                # Use a mock backend that mimics the interface
                mock_get_backend.return_value = mock_backend_instance
                
                app = create_app()
                client = TestClient(app)
                
                # We need to simulate the startup event if lifespan logic is critical, 
                # but TestClient usually handles lifespan.
                # Since we patched _get_backend, the route should use our mock.
                
                # POST /chat
                response = client.post(
                    "/chat",
                    json={
                        "message": "Hello API",
                        "session_id": "test-session-123",
                        "user_id": "test-user"
                    }
                )
                
                # Verify response
                self.assertEqual(response.status_code, 200)
                data = response.json()
                
                # Check response format
                self.assertIn("response", data)
                self.assertIn("session_id", data)
                self.assertIn("message_id", data)
                
                # Verify placeholder echo logic
                self.assertEqual(data["response"], "Echo: Hello API")
                self.assertEqual(data["session_id"], "test-session-123")

    def test_cli_commands(self):
        """
        4. CLI integration: Test argument parsing and command dispatch
        """
        from agentic_brain.cli import create_parser
        
        parser = create_parser()
        
        # Test: agentic check
        args = parser.parse_args(["check"])
        self.assertEqual(args.command, "check")
        self.assertTrue(hasattr(args, "func"))
        
        # Test: agentic serve --port 9000
        args = parser.parse_args(["serve", "--port", "9000"])
        self.assertEqual(args.command, "serve")
        self.assertEqual(args.port, 9000)
        
        # Test: agentic chat --model gpt-5
        args = parser.parse_args(["chat", "--model", "gpt-5"])
        self.assertEqual(args.command, "chat")
        self.assertEqual(args.model, "gpt-5")
        
        # Test: agentic init --name myproject
        args = parser.parse_args(["init", "--name", "myproject"])
        self.assertEqual(args.command, "init")
        self.assertEqual(args.name, "myproject")

if __name__ == "__main__":
    unittest.main()
