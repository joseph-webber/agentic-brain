# SPDX-License-Identifier: Apache-2.0
# Copyright 2024-2026 Agentic Brain Contributors
#
# Licensed under the Apache License, Version 2.0 ("License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Generic multi-backend secrets lookup with configurable prefixes and paths."""

from __future__ import annotations

import logging
import os
from pathlib import Path

try:
    import keyring
    from keyring.errors import KeyringError

    KEYRING_AVAILABLE = True
except ImportError:  # pragma: no cover - optional dependency
    KEYRING_AVAILABLE = False
    KeyringError = Exception  # type: ignore[misc,assignment]
    keyring = None  # type: ignore[assignment]


logger = logging.getLogger(__name__)


def _normalize_prefix(value: str | None) -> str:
    if value is None:
        return ""
    cleaned = value.strip().upper()
    if not cleaned:
        return ""
    return cleaned if cleaned.endswith("_") else f"{cleaned}_"


class AgentSecrets:
    """Secure secret retrieval across keyring, environment variables, and .env files."""

    def __init__(
        self,
        service_name: str = "agentic-brain",
        *,
        env_prefix: str | None = "AGENTIC_BRAIN",
        env_file_path: str | Path | None = None,
        keyring_enabled: bool | None = None,
    ) -> None:
        self.service_name = service_name
        self.env_prefix = _normalize_prefix(env_prefix)
        self._env_cache: dict[str, str] = {}
        self._env_file_loaded = False
        self._keyring_enabled = KEYRING_AVAILABLE if keyring_enabled is None else keyring_enabled

        configured_env_file = env_file_path or os.getenv("AGENTIC_BRAIN_ENV_FILE")
        if configured_env_file is None:
            self._env_file_path = Path.home() / ".agentic-brain" / ".env"
        else:
            self._env_file_path = Path(configured_env_file).expanduser()

    def _load_env_file(self) -> None:
        if self._env_file_loaded or not self._env_file_path.exists():
            self._env_file_loaded = True
            return

        try:
            with self._env_file_path.open() as handle:
                for raw_line in handle:
                    line = raw_line.strip()
                    if not line or line.startswith("#") or "=" not in line:
                        continue

                    key, value = line.split("=", 1)
                    key = key.strip().upper()
                    value = value.strip()

                    if value.startswith('"') and value.endswith('"') or value.startswith("'") and value.endswith("'"):
                        value = value[1:-1]

                    self._env_cache[key] = value
        except OSError as exc:
            logger.warning("Failed to load env file from %s: %s", self._env_file_path, exc)
        finally:
            self._env_file_loaded = True

    @staticmethod
    def _normalize_key(key: str) -> str:
        return key.strip().upper()

    def _environment_key(self, normalized_key: str) -> str:
        return f"{self.env_prefix}{normalized_key}" if self.env_prefix else normalized_key

    def get(self, key: str, default: str | None = None) -> str | None:
        normalized_key = self._normalize_key(key)

        if self._keyring_enabled:
            try:
                value = keyring.get_password(self.service_name, normalized_key)
                if value is not None:
                    return value
            except KeyringError as exc:
                logger.debug("Keyring lookup failed for %s: %s", normalized_key, exc)

        env_key = self._environment_key(normalized_key)
        if env_key in os.environ:
            return os.environ[env_key]

        self._load_env_file()
        if normalized_key in self._env_cache:
            return self._env_cache[normalized_key]

        return default

    def set(self, key: str, value: str) -> bool:
        normalized_key = self._normalize_key(key)

        if self._keyring_enabled:
            try:
                keyring.set_password(self.service_name, normalized_key, value)
                return True
            except KeyringError as exc:
                logger.warning("Keyring storage failed for %s: %s", normalized_key, exc)

        try:
            os.environ[self._environment_key(normalized_key)] = value
            return True
        except Exception as exc:  # pragma: no cover - extremely defensive
            logger.error("Failed to store secret %s in environment: %s", normalized_key, exc)
            return False

    def delete(self, key: str) -> bool:
        normalized_key = self._normalize_key(key)
        deleted = False

        if self._keyring_enabled:
            try:
                keyring.delete_password(self.service_name, normalized_key)
                deleted = True
            except KeyringError:
                pass

        env_key = self._environment_key(normalized_key)
        if env_key in os.environ:
            del os.environ[env_key]
            deleted = True

        return deleted

    def exists(self, key: str) -> bool:
        return self.get(key) is not None

    def list_keys(self) -> list[str]:
        keys = set(self._env_cache.keys())
        self._load_env_file()
        keys.update(self._env_cache.keys())

        if self.env_prefix:
            for env_key in os.environ:
                if env_key.startswith(self.env_prefix):
                    keys.add(env_key[len(self.env_prefix) :])

        return sorted(keys)

    def get_backend_info(self) -> dict[str, bool]:
        return {
            "keyring": self._keyring_enabled,
            "environment_variables": True,
            "env_file": self._env_file_path.exists(),
        }


BotSecrets = AgentSecrets


__all__ = ["AgentSecrets", "BotSecrets"]
