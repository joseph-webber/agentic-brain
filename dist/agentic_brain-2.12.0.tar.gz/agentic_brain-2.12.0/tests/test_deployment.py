# SPDX-License-Identifier: Apache-2.0
# Copyright 2024-2026 Joseph Webber <joseph.webber@me.com>

import subprocess

import pytest


def test_package_builds():
    """Test package can be built"""
    result = subprocess.run(
        ["python", "-m", "build", "--sdist"], capture_output=True, text=True
    )
    assert result.returncode == 0


def test_package_installs():
    """Test package can be installed"""
    # This is verified by the fact tests run
    import agentic_brain

    assert agentic_brain.__version__


def test_cli_available():
    """Test CLI is available after install"""
    result = subprocess.run(
        ["python", "-m", "agentic_brain.cli", "--help"], capture_output=True, text=True
    )
    assert result.returncode == 0
